#!/bin/sh
#SBATCH --job-name=dasa2_assignment3
#SBATCH --mail-type=ALL
#SBATCH --mail-user=anirban.dash@gmail.com


#srun -o Results/result_64_1.log --overcommit --ntasks=64 --partition=debug --time=15 ./assignment3_debug
#srun -o Results/result_128_2.log --overcommit --ntasks=128 --partition=debug --time=15 ./assignment3_debug
#srun -o Results/result_256_4.log --overcommit --ntasks=256 --partition=debug --time=15 ./assignment3_debug
#srun -o Results/result_512_8.log --overcommit --ntasks=512  --partition=debug --time=15 ./assignment3_all
#srun -o Results/result_1024_16.log --overcommit --ntasks=1024 --partition=debug --time=15 ./assignment3_all
#srun -o Results/result_2048_32.log --overcommit --ntasks=2048 --partition=debug --time=15 ./assignment3_all
#srun -o Results/result_4096_64.log --overcommit --ntasks=4096 --partition=medium --time=15 ./assignment3_all
#srun -o Results/result_8192_128.log --overcommit --ntasks=8192 --partition=medium --time=15 ./assignment3_all
srun -o Results/result_8192_128.log --overcommit --ntasks=8192 --partition=medium --time=15 ./wrongResult
